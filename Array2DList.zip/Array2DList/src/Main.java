public class Main {
    public static void main(String[] args){
        Board b = new Board();
        b.printBoard();
        Board b2 = new Board(5,6);
        b2.printBoard();
    }
}