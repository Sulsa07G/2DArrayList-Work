import java.util.ArrayList;
import java.util.Scanner;
public class Board {
    ArrayList<ArrayList<Space>> test;
    int rows = 0;
    int cols = 0;
    int gazooRow = 0;
    int gazooCol = 0;
    private static Scanner input = new Scanner(System.in);
    public Board(){
        test = new ArrayList<>();
        cols = 4;
        rows = 4;
        BuildBoard();
    }

    public Board(int rows, int cols){
        test = new ArrayList<>();
        this.cols = cols;
        this.rows = rows;
        BuildBoard();
    }

    public void printBoard() {
        String toString;
        {
            String result = "";
            for (int i = 0; i < test.size(); i++) {
                for (int j = 0; j < test.get(i).size(); j++) {
                    result += test.get(i).get(j).getConsoleStr();

                }
                result += System.lineSeparator();
            }
            System.out.println(result);
        }


    }

    public void BuildBoard(){
        test.clear();
        for(int i = 0; i < rows; i++){{
            ArrayList<Space> row = new ArrayList<>();
            for(int j = 0; j < cols; j++){
                row.add(new Space());
            }
            test.add(row);
        }
            test.get(gazooRow).get(gazooCol).setOccupant(new LivingThing("Gazoo", 20,ConsoleColors.GREEN));
        }
    }

    public boolean move(char m){
        if(m == 'w'){
            return moveReal(0, -1);
        }else if(m == 'a'){
            return moveReal(-1, 0);
        }else if(m == 's'){
            return moveReal(0, 1);
        }else if(m == 'd'){
            return moveReal(1, 0);
        }else{
            System.out.println("Illegal input");
            return false;
        }
    }

    public boolean validSpace(int x, int y){
        return x >= 0 && x < test.get(0).size() && y >= 0 && y < test.size();
    }

    public boolean moveReal(int x, int y){
        int newX = gazooCol + x;
        int newY = gazooRow + y;
        if(validSpace(newX, newY)){
            gazooCol = newX;
            gazooRow = newY;
            return true;
        }
        return false;
    }
}
